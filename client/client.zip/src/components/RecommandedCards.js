import React from "react";

function RecommandedCards() {
  return (
    <div>
      <div className="cardgifiti-card">
        <p className="giftiallcard-text">Featured Cards</p>
        <p className="allgiftcard-text">
          Buy Most Popular eGift Cards in UAE
          <br />
          Personalized gift vouchers delivered online & redeemable at popular
          Brands
        </p>
        <div style={{ marginLeft: "130px", marginTop: "-35px" }}></div>
      </div>
    </div>
  );
}

export default RecommandedCards;
