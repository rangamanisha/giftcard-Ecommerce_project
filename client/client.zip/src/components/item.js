import styled from "styled-components";

export default styled.div`
  width: 100%;
  height: 100%;
  color: #fff;
  font-size: 4em;
`;
